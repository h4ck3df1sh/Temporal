<%* 
let noteName = (await tp.system.suggester((item) => item.basename, app.vault.getMarkdownFiles().filter(x => x.parent?.path === "_posts"))).basename;
let aliasName = await tp.system.prompt("Alias name");
-%>
[<%aliasName%>](/posts/<%tp.user.date_formatting(noteName)%>/) 