<%* 
let date = tp.date.now('YYYY-MM-DD');
let machineName = await tp.system.prompt("Machine name?") ;
let machineNameNoSpaces = machineName.replace(' ', '-') ;
let platformName = await tp.system.suggester(["HackTheBox", "TryHackMe", "Other"], ["HackTheBox", "TryHackMe", "Other"]);
let difficulty = await tp.system.suggester(["Easy", "Medium", "Hard","Insane"], ["Easy", "Medium", "Hard","Insane"]);
let operatingSystem = await tp.system.suggester(["Linux", "Windows"], ["Linux", "Windows"]);
tp.file.rename(tp.date.now('YYYY-MM-DD')+ "-" + machineNameNoSpaces + "-" +  platformName);
-%>
---
title: <% machineName %> - <% platformName %>
date: <% tp.file.creation_date('YYYY-MM-DD HH:MM') %> +0200
categories: [<% difficulty%>,<% operatingSystem%>]
tags: [<% machineName.toLowerCase()%>, <% platformName.toLowerCase()%>]
---

% Image HERE %

Hello! Today we will be tackling the machine <% machineName %> on <% platformName %>. In this walk-through, we will cover the following points:

1. [Introduction to the machine](#introduction-to-the-machine)
2. [Reconnaissance and information gathering](#reconnaissance-and-information-gathering)
3. [Exploitation and gaining initial access](#exploitation-and-gaining-initial-access)
4. [Privilege escalation techniques](#privilege-escalation-techniques)
5. [Post-exploitation](#post-exploitation)
6. [Conclusion and key takeaways](#conclusion-and-key-takeaways)

Throughout this walk-through, we will be utilizing various tools and techniques to overcome challenges and progress towards rooting the machine. So, let's dive in and get started with the <% platformName %> machine named <% machineName %>. Happy hacking!

## Introduction to the machine
## Reconnaissance and information gathering
## Exploitation and gaining initial access
## Privilege escalation techniques
## Post-exploitation
## Conclusion and key takeaways
