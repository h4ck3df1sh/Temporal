<%* 
let image = (await tp.system.suggester((item) => item.basename + "." + item.extension, app.vault.getFiles().filter(x => x.path.startsWith("assets/img/obsidian"))));
let imageName = image.basename;
let imageExtension = "." + image.extension;
-%>
![<%imageName%>](/assets/img/obsidian/<%imageName%><%imageExtension%>)