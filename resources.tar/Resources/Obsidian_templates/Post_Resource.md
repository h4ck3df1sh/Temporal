<%* 
let date = tp.date.now('YYYY-MM-DD');
let resourceName = await tp.system.prompt("Resource name?") ;
let resourceNameNoSpaces = resourceName.replace(' ', '-') ;
let resourceType = await tp.system.suggester(["Script", "Note","Function", "Other"], ["Script", "Note","Function", "Other"]);
tp.file.rename(tp.date.now('YYYY-MM-DD')+ "-" + resourceNameNoSpaces + "-" +  resourceType);
-%>
---
title: <% resourceName %> - <% resourceType %>
date: <% tp.file.creation_date('YYYY-MM-DD HH:MM') %> +0200
categories: [Resources,<% resourceType%>]
tags: [<% resourceNameNoSpaces.toLowerCase()%>, <% resourceType.toLowerCase()%>]
---

```

```
