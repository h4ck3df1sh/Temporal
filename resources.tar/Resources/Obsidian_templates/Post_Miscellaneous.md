<%* 
let date = tp.date.now('YYYY-MM-DD');
let postName = await tp.system.prompt("Post name?") ;
let postNameNoSpaces = postName.replace(' ', '-') ;
let postType = await tp.system.suggester(["Exploit", "Learning","Building", "Other"], ["Exploit", "Learning","Building", "Other"]);
tp.file.rename(tp.date.now('YYYY-MM-DD')+ "-" + postNameNoSpaces + "-" +  postType);
-%>
---
title: <% postName %> - <% postType %>
date: <% tp.file.creation_date('YYYY-MM-DD HH:MM') %> +0200
categories: [Posts, <%postType%>]
tags: [<% postNameNoSpaces.toLowerCase()%>, <% postType.toLowerCase()%>]
---