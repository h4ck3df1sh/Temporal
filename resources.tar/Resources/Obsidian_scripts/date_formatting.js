function date_formatting (date) {
    let date_format = date.substring(11);
    return `${date_format}`;
}
module.exports = date_formatting;